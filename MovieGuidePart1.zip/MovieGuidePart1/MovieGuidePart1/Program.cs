﻿// Name: 
// Course: 
// Lab: Movie Guide - Part 1


using System;
using System.Collections.Generic;

class Program
{
    // List to store movie titles
    static List<string> movieList = new List<string>
    {
        "Monty Python and the Holy Grail",
        "On the Waterfront",
        "Cat on a Hot Tin Roof"
    };

    static void Main()
    {
        // Main loop to display menu and process commands
        while (true)
        {
            DisplayMenu(); // Display the command menu
            string? command = Console.ReadLine()?.ToLower(); // Read user input and convert to lowercase, ensure it's not null

            if (command != null)
            {
                switch (command)
                {
                    case "list":
                        ListMovies(); // List all movies in the list
                        break;
                    case "add":
                        AddMovie(); // Add a new movie to the list
                        break;
                    case "del":
                        DeleteMovie(); // Delete a movie from the list
                        break;
                    case "exit":
                        return; // Exit the program
                    default:
                        Console.WriteLine("Invalid command. Please try again."); // Handle invalid commands
                        break;
                }
            }
            else
            {
                Console.WriteLine("Input was null. Please try again.");
            }
        }
    }

    // Function to display the command menu
    static void DisplayMenu()
    {
        Console.WriteLine("\nThe Movie List program");
        Console.WriteLine("COMMAND MENU");
        Console.WriteLine("list - List all movies");
        Console.WriteLine("add - Add a movie");
        Console.WriteLine("del - Delete a movie");
        Console.WriteLine("exit - Exit program");
        Console.Write("Command: ");
    }

    // Function to list all movies in the movieList
    static void ListMovies()
    {
        Console.WriteLine("\nMovie List:");
        for (int i = 0; i < movieList.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {movieList[i]}");
        }
    }

    // Function to add a movie to the movieList
    static void AddMovie()
    {
        Console.Write("\nEnter the name of the movie to add: ");
        string? name = Console.ReadLine();
        if (!string.IsNullOrEmpty(name))
        {
            movieList.Add(name);
            Console.WriteLine($"{name} was added.");
        }
        else
        {
            Console.WriteLine("Invalid input. Movie not added.");
        }
    }

    // Function to delete a movie from the movieList
    static void DeleteMovie()
    {
        Console.Write("\nEnter the number of the movie to delete: ");
        int number;
        if (int.TryParse(Console.ReadLine(), out number) && number > 0 && number <= movieList.Count)
        {
            string removed = movieList[number - 1];
            movieList.RemoveAt(number - 1);
            Console.WriteLine($"{removed} was deleted.");
        }
        else
        {
            Console.WriteLine("Invalid movie number."); // Handle invalid number input
        }
    }
}
